<?php
/**
 * WHMCS Provisioning Module for WhiteInfo PBX (FusionPBX / FreeSWITCH)
 * 
 * Module Name: whiteinfopbx
 * Version: 1.1.0
 * 
 * Features:
 * - Automatic Company-wise Subdomain Generation (e.g. apexlimited-pbx.whiteinfobd.com)
 * - Automatic Personal Name Fallback if Company Name is empty (e.g. sajibhossain-pbx.whiteinfobd.com)
 * - Automatic Tenant Admin Login User (username: apexlimited, password: Apexlimited@2010)
 * - Full Tenant Admin Permissions (*.whiteinfobd.com admin group)
 * - Package-wise Extension Provisioning (e.g. 3, 5, 10 extensions)
 * - Automatic Extension 999 creation (Free / Unbilled / Always Active)
 * - Non-Payment Suspension: Package extensions disabled, Extension 999 remains active
 * - Reactivation on Payment: Package extensions restored
 * - Strictly Enforced No-Termination Policy ("terminet hobe na")
 * - 30-Day Call Recording Retention Notice & Management
 * - Client Area Dashboard with PBX Web Login Credentials & MicroSIP Softphone Guide
 */

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

use WHMCS\Database\Capsule;

function whiteinfopbx_MetaData() {
    return [
        'DisplayName' => 'WhiteInfo PBX Billing & Provisioning',
        'APIVersion' => '1.1',
        'RequiresServer' => false,
        'DefaultNonSSLPort' => '80',
        'DefaultSSLPort' => '443',
    ];
}

function whiteinfopbx_ConfigOptions() {
    return [
        'Package Extensions Count' => [
            'Type' => 'text',
            'Size' => '5',
            'Default' => '3',
            'Description' => 'Number of package extensions to create (e.g. 3 creates 101, 102, 103 + Free Extension 999).',
        ],
        'PBX API URL' => [
            'Type' => 'text',
            'Size' => '60',
            'Default' => 'https://pbx1.whiteinfobd.com/billing_api.php',
            'Description' => 'Full URL to PBX billing API endpoint.',
        ],
        'PBX API Key' => [
            'Type' => 'password',
            'Size' => '60',
            'Default' => 'wipbx_557bc41210f5caef05087a48b883fb6f5bf4b1dc7503429f',
            'Description' => 'Secret API Key configured on PBX in /etc/fusionpbx/billing_api.key.',
        ],
        'Default Inbound DID' => [
            'Type' => 'text',
            'Size' => '25',
            'Default' => '',
            'Description' => 'Default Caller ID / DID number (optional, can also be set via custom field "DID").',
        ],
        'Domain Suffix' => [
            'Type' => 'text',
            'Size' => '35',
            'Default' => 'whiteinfobd.com',
            'Description' => 'Base domain suffix for auto-generated subdomains (e.g. whiteinfobd.com).',
        ],
    ];
}

/**
 * Helper to execute PBX API requests
 */
function whiteinfopbx_ApiCall($params, $action, $extraData = []) {
    $apiUrl = trim($params['configoption2']);
    if (empty($apiUrl)) {
        $apiUrl = 'https://pbx1.whiteinfobd.com/billing_api.php';
    }
    
    $apiKey = trim($params['configoption3']);
    if (empty($apiKey)) {
        $apiKey = 'wipbx_557bc41210f5caef05087a48b883fb6f5bf4b1dc7503429f';
    }
    
    $payload = array_merge([
        'action' => $action,
        'domain' => trim($params['domain']),
    ], $extraData);
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $apiUrl);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'X-API-KEY: ' . $apiKey,
    ]);
    
    $response = curl_exec($ch);
    $curlError = curl_error($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($curlError) {
        return ['status' => 'error', 'message' => 'cURL Error: ' . $curlError];
    }
    
    $data = json_decode($response, true);
    if (!is_array($data)) {
        return ['status' => 'error', 'message' => 'Invalid JSON from PBX (HTTP ' . $httpCode . '): ' . substr($response, 0, 200)];
    }
    
    return $data;
}

/**
 * Service Provisioning: Create Account
 * Automatically generates company/name based subdomain: {slug}-pbx.whiteinfobd.com
 * Sets tenant admin username: {slug} and password: {Slug}@2010
 */
function whiteinfopbx_CreateAccount($params) {
    try {
        $serviceId = $params['serviceid'];
        
        // 1. Resolve Company Name or Customer Personal Name
        $companyName = trim($params['clientsdetails']['companyname'] ?? '');
        if (empty($companyName)) {
            $firstName = trim($params['clientsdetails']['firstname'] ?? '');
            $lastName = trim($params['clientsdetails']['lastname'] ?? '');
            $displayName = trim($firstName . ' ' . $lastName);
            if (empty($displayName)) {
                $displayName = 'Client ' . $serviceId;
            }
        } else {
            $displayName = $companyName;
        }
        
        // 2. Generate clean alphanumeric slug (e.g. "Apex Limited" -> "apexlimited")
        $slug = strtolower(preg_replace('/[^a-zA-Z0-9]/', '', $displayName));
        if (empty($slug)) {
            $slug = 'client' . $serviceId;
        }
        
        // 3. Resolve Subdomain: {slug}-pbx.whiteinfobd.com
        $domainSuffix = trim($params['configoption5'] ?? 'whiteinfobd.com');
        if (empty($domainSuffix)) $domainSuffix = 'whiteinfobd.com';
        $domainSuffix = ltrim($domainSuffix, '.');
        
        $domain = trim($params['domain'] ?? '');
        if (empty($domain) || strpos($domain, '.') === false) {
            $domain = $slug . '-pbx.' . $domainSuffix;
        }
        
        // 4. Resolve Tenant Admin Username: {slug} (e.g. "apexlimited")
        $adminUser = trim($params['username'] ?? '');
        if (empty($adminUser) || $adminUser === 'admin') {
            $adminUser = $slug;
        }
        
        // 5. Resolve Tenant Admin Password: e.g. "Apexlimited@2010"
        $adminPass = trim($params['password'] ?? '');
        if (empty($adminPass)) {
            $adminPass = ucfirst($slug) . '@2010';
        }
        
        // 6. Update WHMCS Database (tblhosting) with generated domain, username, password
        Capsule::table('tblhosting')
            ->where('id', $serviceId)
            ->update([
                'domain' => $domain,
                'username' => $adminUser,
                'password' => encrypt($adminPass),
            ]);
            
        // 7. Resolve extension count
        $extCount = 3;
        if (!empty($params['configoptions']['Extensions'])) {
            $extCount = intval($params['configoptions']['Extensions']);
        } elseif (!empty($params['configoptions']['ext_count'])) {
            $extCount = intval($params['configoptions']['ext_count']);
        } elseif (!empty($params['customfields']['Extension Count'])) {
            $extCount = intval($params['customfields']['Extension Count']);
        } elseif (!empty($params['configoption1'])) {
            $extCount = intval($params['configoption1']);
        }
        if ($extCount < 1) $extCount = 1;
        
        // 8. Resolve DID
        $did = !empty($params['customfields']['DID']) 
            ? trim($params['customfields']['DID']) 
            : trim($params['configoption4']);
            
        // 9. Call PBX API
        $extra = [
            'domain' => $domain,
            'company_name' => $displayName,
            'admin_username' => $adminUser,
            'admin_password' => $adminPass,
            'ext_count' => $extCount,
            'did' => $did,
        ];
        
        $res = whiteinfopbx_ApiCall($params, 'create', $extra);
        
        if (isset($res['status']) && $res['status'] === 'success') {
            // Format notes with extension details
            $note = "=== PBX PROVISIONING DETAILS ===\n";
            $note .= "Tenant Domain: " . $res['domain'] . "\n";
            $note .= "Tenant Portal: https://" . $res['domain'] . "\n";
            $note .= "Central Portal: https://pbx1.whiteinfobd.com\n";
            $note .= "Tenant Admin User: " . $adminUser . "\n";
            $note .= "Tenant Admin Pass: " . $adminPass . "\n";
            $note .= "SIP Server: " . $res['sip_server'] . ":5060\n\n";
            $note .= "PACKAGE EXTENSIONS:\n";
            foreach ($res['package_extensions'] as $pe) {
                $note .= "  • Ext " . $pe['extension'] . " (Pass: " . $pe['password'] . ")\n";
            }
            $note .= "\nFREE UNBILLED SUPPORT EXTENSION:\n";
            $note .= "  • Ext " . $res['free_extension_999']['extension'] . " (Pass: " . $res['free_extension_999']['password'] . ") [Always Active]\n";
            
            // Append to admin notes
            $existingNotes = Capsule::table('tblhosting')->where('id', $serviceId)->value('notes');
            Capsule::table('tblhosting')->where('id', $serviceId)->update([
                'notes' => trim($existingNotes . "\n\n" . $note)
            ]);
            
            return 'success';
        } else {
            return $res['message'] ?? 'PBX creation failed';
        }
    } catch (\Exception $e) {
        return 'Exception: ' . $e->getMessage();
    }
}

/**
 * Service Suspension on Non-Payment:
 * Disables package extensions, Extension 999 remains ACTIVE!
 */
function whiteinfopbx_SuspendAccount($params) {
    try {
        $res = whiteinfopbx_ApiCall($params, 'suspend');
        if (isset($res['status']) && $res['status'] === 'success') {
            return 'success';
        }
        return $res['message'] ?? 'PBX suspension failed';
    } catch (\Exception $e) {
        return 'Exception: ' . $e->getMessage();
    }
}

/**
 * Service Unsuspension on Payment:
 * Re-enables all package extensions and services!
 */
function whiteinfopbx_UnsuspendAccount($params) {
    try {
        $res = whiteinfopbx_ApiCall($params, 'unsuspend');
        if (isset($res['status']) && $res['status'] === 'success') {
            return 'success';
        }
        return $res['message'] ?? 'PBX unsuspension failed';
    } catch (\Exception $e) {
        return 'Exception: ' . $e->getMessage();
    }
}

/**
 * Service Termination:
 * Strictly enforces "terminet hobe na" rule!
 * Domain, extensions, recordings, and CDRs are NEVER deleted.
 */
function whiteinfopbx_TerminateAccount($params) {
    try {
        $res = whiteinfopbx_ApiCall($params, 'terminate');
        if (isset($res['status']) && $res['status'] === 'success') {
            return 'success';
        }
        return $res['message'] ?? 'PBX termination soft-lock failed';
    } catch (\Exception $e) {
        return 'Exception: ' . $e->getMessage();
    }
}

/**
 * Admin Area Custom Buttons
 */
function whiteinfopbx_AdminCustomButtonArray() {
    return [
        'Sync Status & Extensions' => 'SyncStatus',
        'Test API Connection' => 'TestConnection',
    ];
}

function whiteinfopbx_SyncStatus($params) {
    $res = whiteinfopbx_ApiCall($params, 'status');
    if (isset($res['status']) && $res['status'] === 'success') {
        return 'Domain: ' . $res['domain'] . ' | Extensions: ' . $res['extension_count'] . ' | 30d Recordings: ' . $res['recordings_count_30d'];
    }
    return $res['message'] ?? 'Failed to query PBX status';
}

function whiteinfopbx_TestConnection($params) {
    $res = whiteinfopbx_ApiCall($params, 'ping');
    if (isset($res['status']) && $res['status'] === 'success') {
        return 'Success! Connected to ' . $res['service'] . ' (' . $res['pbx_host'] . ') at ' . $res['time'];
    }
    return $res['message'] ?? 'PBX API connection test failed';
}

/**
 * Client Area Dashboard
 */
function whiteinfopbx_ClientArea($params) {
    $statusData = whiteinfopbx_ApiCall($params, 'status');
    $isSuspended = ($params['status'] === 'Suspended');
    $domain = !empty($statusData['domain']) ? $statusData['domain'] : $params['domain'];
    $username = htmlspecialchars($params['username'] ?? '');
    $password = htmlspecialchars($params['password'] ?? '');
    $extensions = !empty($statusData['extensions']) ? $statusData['extensions'] : [];
    $recCount = isset($statusData['recordings_count_30d']) ? intval($statusData['recordings_count_30d']) : 0;
    
    // Build extensions table rows
    $extRows = '';
    foreach ($extensions as $ext) {
        $extNum = htmlspecialchars($ext['extension']);
        $extName = htmlspecialchars($ext['effective_caller_id_name']);
        $enabled = !empty($ext['enabled']);
        
        $is999 = ($extNum === '999');
        $rowBadge = '';
        if ($is999) {
            $rowBadge = '<span class="label label-primary" style="background:#0284c7;color:#fff;padding:3px 8px;border-radius:4px;font-size:11px;">FREE / SUPPORT (ALWAYS ACTIVE)</span>';
        } elseif ($enabled) {
            $rowBadge = '<span class="label label-success" style="background:#16a34a;color:#fff;padding:3px 8px;border-radius:4px;font-size:11px;">ACTIVE</span>';
        } else {
            $rowBadge = '<span class="label label-danger" style="background:#dc2626;color:#fff;padding:3px 8px;border-radius:4px;font-size:11px;">OFF (OVERDUE)</span>';
        }
        
        $extRows .= "<tr>
            <td><strong style='font-size:15px;color:#1e293b;'>{$extNum}</strong></td>
            <td>{$extName}</td>
            <td>{$domain}</td>
            <td>{$rowBadge}</td>
        </tr>";
    }
    
    $bannerHtml = '';
    if ($isSuspended) {
        $bannerHtml = '<div style="background:#fee2e2;border:1px solid #ef4444;border-radius:8px;padding:15px;margin-bottom:20px;color:#991b1b;">
            <h4 style="margin:0 0 8px 0;font-weight:700;"><i class="fa fa-exclamation-triangle"></i> Service Suspended (Invoice Overdue)</h4>
            <p style="margin:0 0 5px 0;">All customer extensions have been turned off due to non-payment. Please pay your invoice to instantly restore your package extensions.</p>
            <p style="margin:0;font-weight:600;"><i class="fa fa-check-circle" style="color:#16a34a;"></i> <strong>Extension 999</strong> remains ACTIVE and fully available for free emergency and support calling!</p>
        </div>';
    }
    
    $html = <<<HTML
<div style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;">
    {$bannerHtml}
    
    <!-- PBX Tenant Overview -->
    <div style="display:flex;justify-content:space-between;align-items:center;background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:18px 24px;margin-bottom:24px;flex-wrap:wrap;gap:15px;">
        <div>
            <div style="font-size:12px;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:0.5px;">PBX Tenant Subdomain</div>
            <div style="font-size:22px;font-weight:800;color:#0f172a;margin-top:2px;">
                <a href="https://{$domain}" target="_blank" style="color:#2563eb;text-decoration:none;">{$domain}</a>
            </div>
            <div style="font-size:13px;color:#64748b;margin-top:4px;">
                <i class="fa fa-server"></i> SIP Server: <strong>pbx1.whiteinfobd.com:5060</strong> (UDP)
            </div>
        </div>
        <div>
            <a href="https://{$domain}" target="_blank" class="btn btn-primary" style="background:#2563eb;color:#fff;border-radius:6px;padding:10px 18px;font-weight:600;text-decoration:none;display:inline-block;">
                <i class="fa fa-external-link"></i> Login to PBX Portal
            </a>
        </div>
    </div>

    <!-- Web Portal Admin Credentials -->
    <div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:10px;padding:18px 20px;margin-bottom:24px;color:#166534;">
        <h4 style="margin:0 0 10px 0;font-weight:700;color:#166534;"><i class="fa fa-lock"></i> PBX Web Portal Login Credentials (*.whiteinfobd.com)</h4>
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px;font-size:14px;">
            <div style="background:#fff;padding:12px 16px;border-radius:6px;border:1px solid #dcfce7;">
                <div style="font-size:12px;color:#64748b;font-weight:600;">Web Portal URL</div>
                <div style="margin-top:4px;"><a href="https://{$domain}" target="_blank" style="color:#2563eb;font-weight:700;">https://{$domain}</a></div>
            </div>
            <div style="background:#fff;padding:12px 16px;border-radius:6px;border:1px solid #dcfce7;">
                <div style="font-size:12px;color:#64748b;font-weight:600;">Login Username</div>
                <div style="margin-top:4px;font-family:monospace;font-size:15px;font-weight:700;color:#0f172a;">{$username}</div>
            </div>
            <div style="background:#fff;padding:12px 16px;border-radius:6px;border:1px solid #dcfce7;">
                <div style="font-size:12px;color:#64748b;font-weight:600;">Login Password</div>
                <div style="margin-top:4px;font-family:monospace;font-size:15px;font-weight:700;color:#0f172a;">{$password}</div>
            </div>
            <div style="background:#fff;padding:12px 16px;border-radius:6px;border:1px solid #dcfce7;">
                <div style="font-size:12px;color:#64748b;font-weight:600;">User Role & Permission</div>
                <div style="margin-top:4px;font-weight:700;color:#16a34a;"><i class="fa fa-check-shield"></i> Tenant Administrator</div>
            </div>
        </div>
    </div>

    <!-- Provisioned Extensions Table -->
    <div style="background:#fff;border:1px solid #e2e8f0;border-radius:10px;overflow:hidden;margin-bottom:24px;box-shadow:0 1px 3px rgba(0,0,0,0.05);">
        <div style="background:#f1f5f9;padding:14px 20px;font-weight:700;font-size:15px;color:#1e293b;border-bottom:1px solid #e2e8f0;display:flex;justify-content:space-between;align-items:center;">
            <span><i class="fa fa-phone"></i> Provisioned Extensions</span>
            <span style="font-size:12px;font-weight:600;color:#64748b;">30-Day Call Recordings: <strong>{$recCount} calls stored</strong></span>
        </div>
        <div class="table-responsive" style="margin:0;">
            <table class="table" style="margin-bottom:0;width:100%;">
                <thead>
                    <tr style="background:#f8fafc;font-size:12px;text-transform:uppercase;color:#64748b;">
                        <th>Extension</th>
                        <th>Caller ID / Name</th>
                        <th>SIP Domain Context</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    {$extRows}
                </tbody>
            </table>
        </div>
    </div>

    <!-- Softphone Setup Quick Guide -->
    <div style="background:#f0f9ff;border:1px solid #bae6fd;border-radius:10px;padding:20px;color:#0369a1;">
        <h4 style="margin:0 0 10px 0;font-weight:700;color:#0369a1;"><i class="fa fa-info-circle"></i> Quick Setup Guide (MicroSIP / Zoiper / Softphone)</h4>
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:15px;font-size:13px;margin-top:10px;">
            <div style="background:#fff;padding:12px;border-radius:6px;border:1px solid #e0f2fe;">
                <div style="font-weight:700;color:#0c4a6e;">SIP Server / Proxy</div>
                <div style="font-family:monospace;color:#0369a1;margin-top:3px;">pbx1.whiteinfobd.com:5060</div>
            </div>
            <div style="background:#fff;padding:12px;border-radius:6px;border:1px solid #e0f2fe;">
                <div style="font-weight:700;color:#0c4a6e;">Domain / Realm</div>
                <div style="font-family:monospace;color:#0369a1;margin-top:3px;">{$domain}</div>
            </div>
            <div style="background:#fff;padding:12px;border-radius:6px;border:1px solid #e0f2fe;">
                <div style="font-weight:700;color:#0c4a6e;">Transport & Codecs</div>
                <div style="font-family:monospace;color:#0369a1;margin-top:3px;">UDP | PCMU, PCMA, G722</div>
            </div>
            <div style="background:#fff;padding:12px;border-radius:6px;border:1px solid #e0f2fe;">
                <div style="font-weight:700;color:#0c4a6e;">Call Recording Retention</div>
                <div style="font-family:monospace;color:#0369a1;margin-top:3px;">Last 30 Days (Auto-purged)</div>
            </div>
        </div>
    </div>
</div>
HTML;

    return $html;
}

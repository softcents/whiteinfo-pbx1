# WhiteInfo PBX Multi-Server Provisioning & Billing Module for WHMCS

**Module Version:** 1.2.0 (Multi-Server Enterprise Edition)  
**Supported PBX:** FusionPBX 5.x / FreeSWITCH 1.10.x  
**Supported WHMCS:** WHMCS 7.x / 8.x  
**Copyright:** © 2026 Softcents Systems / WhiteInfo. All rights reserved.

---

## Key Features

1. **Native WHMCS Multi-Server & Cluster Support**:
   - Supports unlimited PBX server nodes (`pbx1.whiteinfobd.com`, `pbx2.whiteinfobd.com`, etc.).
   - Compatible with WHMCS **Server Groups** (Round-Robin load balancing or Fill-Active-Server-Until-Full).
   - Dynamic routing of provisioning requests to the assigned PBX server node.

2. **Automated Cloudflare DNS Routing**:
   - Automatically creates or updates Cloudflare DNS A records (`{subdomain} -> {node_ip}`).
   - Instant routing for multi-server IPs while sharing the Let's Encrypt Wildcard SSL (`*.whiteinfobd.com`).

3. **Intelligent Tenant Subdomain Generation**:
   - If Company Name is set: `{companyname}-pbx.whiteinfobd.com` (e.g. `apexlimited-pbx.whiteinfobd.com`).
   - If Company Name is empty: `{firstname}{lastname}-pbx.whiteinfobd.com` fallback.

4. **Tenant Admin & Group Permissions**:
   - Creates tenant admin username (e.g. `apexlimited`) and secure password (`Apexlimited@2010`).
   - Assigns full `admin` group permission on their specific tenant subdomain.

5. **Package Extensions & Free Unbilled Extension 999**:
   - Auto-creates package extensions (e.g. 101, 102, 103).
   - Auto-creates Free Support Extension `999` (never billed, always active).

6. **Automated Inbound Ring Group 6000 & Dialplans**:
   - Ring Group 6000 rings all provisioned extensions simultaneously.
   - Clean Caller ID (strictly strips `#` prefixes).
   - Outbound routes auto-linked to active BTCL gateway with pattern `^(?:#)?(?:\+?88)?(\d{11})$`.

7. **Invoice Overdue Suspension Logic**:
   - Automatically disables package extensions (101, 102, 103...) and flushes FreeSWITCH SIP registrations.
   - **Extension 999 remains 100% active** for free emergency and support calls.

8. **Package Upgrade / Downgrade (ChangePackage)**:
   - Increasing extension count creates additional extensions and adds them to Ring Group 6000.
   - Downsizing disables excess extensions safely.

9. **Strictly Enforced No-Termination Policy ("terminet hobe na")**:
   - Service cancellation or termination does NOT delete PBX data, extensions, CDRs, or 30-day recordings.

10. **Rich Client Area Dashboard & One-Click Login**:
    - One-click PBX Web Portal login without entering credentials manually.
    - Extension list with real-time status badges.
    - MicroSIP and Softphone configuration guide.
    - 30-day call recording retention status.

---

## Installation & Setup

1. Extract this module to your WHMCS directory:
   ```bash
   cd /path/to/whmcs
   wget -O whiteinfopbx_whmcs_module.zip https://pbx1.whiteinfobd.com/whiteinfopbx_whmcs_module.zip
   unzip -o whiteinfopbx_whmcs_module.zip
   rm whiteinfopbx_whmcs_module.zip
   ```

2. Configure PBX Servers in WHMCS:
   - Navigate to **System Settings** ➔ **Servers** (or **Setup** ➔ **Products/Services** ➔ **Servers**).
   - Click **Add New Server**:
     - **Name:** `PBX-01 (Primary)`
     - **Hostname:** `pbx1.whiteinfobd.com`
     - **IP Address:** `165.99.219.124`
     - **Type / Module:** `WhiteInfo PBX Multi-Server Billing & Provisioning`
     - **Access Hash:** `wipbx_557bc41210f5caef05087a48b883fb6f5bf4b1dc7503429f`
     - **Secure:** Check *Tick to use SSL for Connections* (Port: 443)
     - Click **Test Connection** (returns Success).
   - Repeat for `PBX-02`, `PBX-03`, etc.

3. Create a Server Group:
   - Click **Create New Group**:
     - **Group Name:** `PBX Production Cluster`
     - **Fill Type:** Choose `Add to the least full server` or `Fill active server until full`.
     - Add your PBX servers to the group.

4. Configure your PBX Product:
   - Go to **Products/Services** ➔ Select your PBX package.
   - Under **Module Settings**:
     - **Module Name:** `WhiteInfo PBX Multi-Server Billing & Provisioning`
     - **Server Group:** Select `PBX Production Cluster`.
     - **Package Extensions Count:** e.g. `3`
     - **Domain Suffix:** `whiteinfobd.com`
     - Set automatic setup on payment or order placement.

<?php
/**
 * WHMCS Provisioning Module for WhiteInfo PBX (FusionPBX / FreeSWITCH)
 * 
 * Module Name: whiteinfopbx
 * Version: 1.4.0 (Extension Password Management Edition)
 * 
 * Features:
 * - Full WHMCS Multi-Server Pool & Server Groups support (Round-Robin & Fill-Until-Full)
 * - Automatic Company-wise Subdomain Generation (e.g. apexlimited-pbx.whiteinfobd.com)
 * - Automatic Personal Name Fallback if Company Name is empty (e.g. sajibhossain-pbx.whiteinfobd.com)
 * - Automatic Cloudflare DNS A Record creation/update for assigned PBX server IP
 * - Automatic Tenant Admin Login User (username: apexlimited, password: Apexlimited@2010)
 * - Full Tenant Admin Permissions (*.whiteinfobd.com admin group)
 * - Package-wise Extension Provisioning (e.g. 3, 5, 10 extensions)
 * - Automatic Extension 999 creation (Free / Unbilled / Always Active)
 * - Non-Payment Suspension: Package extensions disabled, Extension 999 remains active
 * - Reactivation on Payment: Package extensions restored
 * - Strictly Enforced No-Termination Policy ("terminet hobe na")
 * - 30-Day Call Recording Retention Notice & Management
 * - Dynamic Multi-Server Client Area Dashboard & Softphone Guide
 */

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

use WHMCS\Database\Capsule;

/**
 * Module Metadata
 */
function whiteinfopbx_MetaData() {
    return [
        'DisplayName' => 'WhiteInfo PBX Multi-Server Billing & Provisioning',
        'APIVersion' => '1.4',
        'RequiresServer' => true,
        'DefaultNonSSLPort' => '80',
        'DefaultSSLPort' => '443',
    ];
}

/**
 * Module Configuration Options
 */
function whiteinfopbx_ConfigOptions() {
    return [
        'Package Extensions Count' => [
            'Type' => 'text',
            'Size' => '5',
            'Default' => '3',
            'Description' => 'Number of package extensions to create (e.g. 3 creates 101, 102, 103 + Free Extension 999).',
        ],
        'Domain Suffix' => [
            'Type' => 'text',
            'Size' => '35',
            'Default' => 'whiteinfobd.com',
            'Description' => 'Base domain suffix for auto-generated subdomains (e.g. whiteinfobd.com).',
        ],
        'Default Inbound DID' => [
            'Type' => 'text',
            'Size' => '25',
            'Default' => '',
            'Description' => 'Default Caller ID / DID number (optional, can also be set via custom field "DID").',
        ],
        'Auto Cloudflare DNS' => [
            'Type' => 'yesno',
            'Default' => 'yes',
            'Description' => 'Automatically create/update Cloudflare DNS A record pointing tenant subdomain to assigned PBX node IP.',
        ],
        'Cloudflare API Token' => [
            'Type' => 'password',
            'Size' => '60',
            'Default' => 'cfat_16MYIKB27rfwRDAioIfFBTbQvgN8jSROhQInimFka7181544',
            'Description' => 'Cloudflare API Token with DNS Edit permissions.',
        ],
        'Cloudflare Zone ID' => [
            'Type' => 'text',
            'Size' => '40',
            'Default' => 'eb40ccf525470b1e27d2eb98c9cd7d17',
            'Description' => 'Cloudflare Zone ID for whiteinfobd.com.',
        ],
        'Fallback PBX API URL' => [
            'Type' => 'text',
            'Size' => '60',
            'Default' => 'https://pbx1.whiteinfobd.com/billing_api.php',
            'Description' => 'Fallback API endpoint if no WHMCS Server is assigned.',
        ],
        'Fallback PBX API Key' => [
            'Type' => 'password',
            'Size' => '60',
            'Default' => 'wipbx_557bc41210f5caef05087a48b883fb6f5bf4b1dc7503429f',
            'Description' => 'Fallback API key if no Server Access Hash is configured.',
        ],
    ];
}

/**
 * Cloudflare DNS Helper for Multi-PBX Server routing
 */
function whiteinfopbx_EnsureCloudflareDns($subdomain, $targetIp, $params = []) {
    $cfToken = !empty($params['configoption5']) ? trim($params['configoption5']) : 'cfat_16MYIKB27rfwRDAioIfFBTbQvgN8jSROhQInimFka7181544';
    $zoneId  = !empty($params['configoption6']) ? trim($params['configoption6']) : 'eb40ccf525470b1e27d2eb98c9cd7d17';
    
    if (empty($cfToken) || empty($zoneId) || empty($subdomain) || empty($targetIp)) {
        return false;
    }
    
    // Check if DNS record already exists
    $ch = curl_init("https://api.cloudflare.com/client/v4/zones/{$zoneId}/dns_records?name=" . urlencode($subdomain) . "&type=A");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Authorization: Bearer {$cfToken}",
        "Content-Type: application/json"
    ]);
    $res = json_decode(curl_exec($ch), true);
    curl_close($ch);
    
    $recordId   = $res['result'][0]['id'] ?? null;
    $existingIp = $res['result'][0]['content'] ?? null;
    
    if ($recordId && $existingIp === $targetIp) {
        return true; // Already accurately pointed
    }
    
    $payload = json_encode([
        "type" => "A",
        "name" => $subdomain,
        "content" => $targetIp,
        "ttl" => 120,
        "proxied" => false
    ]);
    
    if ($recordId) {
        $ch = curl_init("https://api.cloudflare.com/client/v4/zones/{$zoneId}/dns_records/{$recordId}");
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
    } else {
        $ch = curl_init("https://api.cloudflare.com/client/v4/zones/{$zoneId}/dns_records");
        curl_setopt($ch, CURLOPT_POST, true);
    }
    
    curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Authorization: Bearer {$cfToken}",
        "Content-Type: application/json"
    ]);
    $out = json_decode(curl_exec($ch), true);
    curl_close($ch);
    
    return ($out['success'] ?? false) === true;
}

/**
 * Multi-Server Dynamic API Caller
 */
function whiteinfopbx_ApiCall($params, $action, $extraData = []) {
    // 1. Dynamic Server Hostname / IP resolution (Multi-Server Support)
    if (!empty($params['serverhostname'])) {
        $proto = (!empty($params['serversecure']) || (isset($params['serverport']) && $params['serverport'] == 443)) ? 'https://' : 'http://';
        $portStr = (!empty($params['serverport']) && !in_array($params['serverport'], [80, 443])) ? ':' . $params['serverport'] : '';
        $apiUrl = $proto . $params['serverhostname'] . $portStr . '/billing_api.php';
    } elseif (!empty($params['serverip'])) {
        $proto = (!empty($params['serversecure']) || (isset($params['serverport']) && $params['serverport'] == 443)) ? 'https://' : 'http://';
        $portStr = (!empty($params['serverport']) && !in_array($params['serverport'], [80, 443])) ? ':' . $params['serverport'] : '';
        $apiUrl = $proto . $params['serverip'] . $portStr . '/billing_api.php';
    } elseif (!empty($params['configoption7'])) {
        $apiUrl = trim($params['configoption7']);
    } elseif (!empty($params['configoption2']) && strpos($params['configoption2'], 'http') !== false) {
        $apiUrl = trim($params['configoption2']);
    } else {
        $apiUrl = 'https://pbx1.whiteinfobd.com/billing_api.php';
    }
    
    // 2. Dynamic API Key resolution (Server Access Hash -> Server Password -> Fallback Config)
    if (!empty($params['serveraccesshash'])) {
        $apiKey = trim($params['serveraccesshash']);
    } elseif (!empty($params['serverpassword'])) {
        $apiKey = trim($params['serverpassword']);
    } elseif (!empty($params['configoption8'])) {
        $apiKey = trim($params['configoption8']);
    } elseif (!empty($params['configoption3']) && strpos($params['configoption3'], 'wipbx_') === 0) {
        $apiKey = trim($params['configoption3']);
    } else {
        $apiKey = 'wipbx_557bc41210f5caef05087a48b883fb6f5bf4b1dc7503429f';
    }
    
    $payload = array_merge([
        'action' => $action,
        'domain' => trim($params['domain'] ?? ''),
    ], $extraData);
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $apiUrl);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'X-API-KEY: ' . $apiKey,
    ]);
    
    $response = curl_exec($ch);
    $curlError = curl_error($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($curlError) {
        return ['status' => 'error', 'message' => 'cURL Error (' . $apiUrl . '): ' . $curlError];
    }
    
    $data = json_decode($response, true);
    if (!is_array($data)) {
        return ['status' => 'error', 'message' => 'Invalid JSON from PBX (' . $apiUrl . ' - HTTP ' . $httpCode . '): ' . substr($response, 0, 200)];
    }
    
    return $data;
}

/**
 * Service Provisioning: Create Account
 */
function whiteinfopbx_CreateAccount($params) {
    try {
        $serviceId = $params['serviceid'];
        
        // 1. Resolve Company Name or Customer Personal Name
        $companyName = trim($params['clientsdetails']['companyname'] ?? '');
        if (empty($companyName)) {
            $firstName = trim($params['clientsdetails']['firstname'] ?? '');
            $lastName = trim($params['clientsdetails']['lastname'] ?? '');
            $displayName = trim($firstName . ' ' . $lastName);
            if (empty($displayName)) {
                $displayName = 'Client ' . $serviceId;
            }
        } else {
            $displayName = $companyName;
        }
        
        // 2. Generate clean alphanumeric slug (e.g. "Apex Limited" -> "apexlimited")
        $slug = strtolower(preg_replace('/[^a-zA-Z0-9]/', '', $displayName));
        if (empty($slug)) {
            $slug = 'client' . $serviceId;
        }
        
        // 3. Resolve Subdomain: {slug}-pbx.whiteinfobd.com
        $domainSuffix = 'whiteinfobd.com';
        if (!empty($params['configoption2']) && strpos($params['configoption2'], 'http') === false) {
            $domainSuffix = trim($params['configoption2']);
        } elseif (!empty($params['configoption5']) && strpos($params['configoption5'], 'white') !== false) {
            $domainSuffix = trim($params['configoption5']);
        }
        $domainSuffix = ltrim($domainSuffix, '.');
        
        $domain = trim($params['domain'] ?? '');
        if (empty($domain) || strpos($domain, '.') === false) {
            $domain = $slug . '-pbx.' . $domainSuffix;
        }
        
        // 4. Resolve Tenant Admin Username: {slug} (e.g. "apexlimited")
        $adminUser = trim($params['username'] ?? '');
        if (empty($adminUser) || $adminUser === 'admin') {
            $adminUser = $slug;
        }
        
        // 5. Resolve Tenant Admin Password: e.g. "Apexlimited@2010"
        $adminPass = trim($params['password'] ?? '');
        if (empty($adminPass)) {
            $adminPass = ucfirst($slug) . '@2010';
        }
        
        // 6. Update WHMCS Database (tblhosting) with generated domain, username, password
        Capsule::table('tblhosting')
            ->where('id', $serviceId)
            ->update([
                'domain' => $domain,
                'username' => $adminUser,
                'password' => encrypt($adminPass),
            ]);
            
        // 7. Resolve Extension Count
        $extCount = 3;
        if (!empty($params['configoptions']['Extensions'])) {
            $extCount = intval($params['configoptions']['Extensions']);
        } elseif (!empty($params['configoptions']['ext_count'])) {
            $extCount = intval($params['configoptions']['ext_count']);
        } elseif (!empty($params['customfields']['Extension Count'])) {
            $extCount = intval($params['customfields']['Extension Count']);
        } elseif (!empty($params['configoption1'])) {
            $extCount = intval($params['configoption1']);
        }
        if ($extCount < 1) $extCount = 1;
        
        // 8. Resolve DID
        $did = !empty($params['customfields']['DID']) 
            ? trim($params['customfields']['DID']) 
            : (!empty($params['configoption3']) && strpos($params['configoption3'], 'wipbx_') === false ? trim($params['configoption3']) : '');
            
        // 9. Call PBX API on the assigned server node
        $extra = [
            'domain' => $domain,
            'company_name' => $displayName,
            'admin_username' => $adminUser,
            'admin_password' => $adminPass,
            'ext_count' => $extCount,
            'did' => $did,
        ];
        
        $res = whiteinfopbx_ApiCall($params, 'create', $extra);
        
        if (isset($res['status']) && $res['status'] === 'success') {
            // 10. Automatically point Cloudflare DNS A record to assigned PBX node IP
            $targetIp = !empty($params['serverip']) ? $params['serverip'] : ($res['server_ip'] ?? '165.99.219.124');
            $autoDns = !empty($params['configoption4']) ? ($params['configoption4'] == 'on' || $params['configoption4'] == 'yes') : true;
            if ($autoDns && !empty($targetIp)) {
                whiteinfopbx_EnsureCloudflareDns($domain, $targetIp, $params);
            }
            
            $serverLabel = !empty($params['serverhostname']) ? $params['serverhostname'] : ($params['serverip'] ?? 'pbx1.whiteinfobd.com');
            
            // Format notes with extension details
            $note = "=== WHITEINFO PBX PROVISIONING DETAILS ===
";
            $note .= "PBX Server Node: " . $serverLabel . " (" . $targetIp . ")
";
            $note .= "Tenant Subdomain: " . $res['domain'] . "
";
            $note .= "Tenant Web Portal: https://" . $res['domain'] . "
";
            $note .= "Node Central Portal: https://" . $serverLabel . "
";
            $note .= "Tenant Admin User: " . $adminUser . "
";
            $note .= "Tenant Admin Pass: " . $adminPass . "
";
            $note .= "SIP Server: " . $serverLabel . ":5060

";
            $note .= "PACKAGE EXTENSIONS:
";
            foreach ($res['package_extensions'] as $pe) {
                $note .= "  • Ext " . $pe['extension'] . " (Pass: " . $pe['password'] . ")
";
            }
            $note .= "
FREE UNBILLED SUPPORT EXTENSION:
";
            $note .= "  • Ext " . $res['free_extension_999']['extension'] . " (Pass: " . $res['free_extension_999']['password'] . ") [Always Active]
";
            
            $existingNotes = Capsule::table('tblhosting')->where('id', $serviceId)->value('notes');
            Capsule::table('tblhosting')->where('id', $serviceId)->update([
                'notes' => trim($existingNotes . "

" . $note)
            ]);
            
            return 'success';
        } else {
            return $res['message'] ?? 'PBX creation failed';
        }
    } catch (\Exception $e) {
        return 'Exception: ' . $e->getMessage();
    }
}

/**
 * Service Suspension on Non-Payment:
 * Disables package extensions, Extension 999 remains ACTIVE!
 */
function whiteinfopbx_SuspendAccount($params) {
    try {
        $res = whiteinfopbx_ApiCall($params, 'suspend');
        if (isset($res['status']) && $res['status'] === 'success') {
            if (!empty($res['created_extensions'])) {
                $note = "=== PACKAGE UPGRADE (" . date('Y-m-d H:i:s') . ") ===\n";
                $note .= "Total Extensions: " . $extCount . "\n";
                $note .= "Newly Added Extensions:\n";
                foreach ($res['created_extensions'] as $ce) {
                    $note .= "  • Ext " . $ce['extension'] . " (Pass: " . $ce['password'] . ")\n";
                }
                $existingNotes = Capsule::table('tblhosting')->where('id', $params['serviceid'])->value('notes');
                Capsule::table('tblhosting')->where('id', $params['serviceid'])->update([
                    'notes' => trim($existingNotes . "\n\n" . $note)
                ]);
            }
            return 'success';
        }
        return $res['message'] ?? 'PBX suspension failed';
    } catch (\Exception $e) {
        return 'Exception: ' . $e->getMessage();
    }
}

/**
 * Service Unsuspension on Payment:
 * Re-enables all package extensions and services!
 */
function whiteinfopbx_UnsuspendAccount($params) {
    try {
        $res = whiteinfopbx_ApiCall($params, 'unsuspend');
        if (isset($res['status']) && $res['status'] === 'success') {
            if (!empty($res['created_extensions'])) {
                $note = "=== PACKAGE UPGRADE (" . date('Y-m-d H:i:s') . ") ===\n";
                $note .= "Total Extensions: " . $extCount . "\n";
                $note .= "Newly Added Extensions:\n";
                foreach ($res['created_extensions'] as $ce) {
                    $note .= "  • Ext " . $ce['extension'] . " (Pass: " . $ce['password'] . ")\n";
                }
                $existingNotes = Capsule::table('tblhosting')->where('id', $params['serviceid'])->value('notes');
                Capsule::table('tblhosting')->where('id', $params['serviceid'])->update([
                    'notes' => trim($existingNotes . "\n\n" . $note)
                ]);
            }
            return 'success';
        }
        return $res['message'] ?? 'PBX unsuspension failed';
    } catch (\Exception $e) {
        return 'Exception: ' . $e->getMessage();
    }
}

/**
 * Service Termination:
 * Strictly enforces "terminet hobe na" rule!
 * Domain, extensions, recordings, and CDRs are NEVER deleted.
 */
function whiteinfopbx_TerminateAccount($params) {
    try {
        $res = whiteinfopbx_ApiCall($params, 'terminate');
        if (isset($res['status']) && $res['status'] === 'success') {
            if (!empty($res['created_extensions'])) {
                $note = "=== PACKAGE UPGRADE (" . date('Y-m-d H:i:s') . ") ===\n";
                $note .= "Total Extensions: " . $extCount . "\n";
                $note .= "Newly Added Extensions:\n";
                foreach ($res['created_extensions'] as $ce) {
                    $note .= "  • Ext " . $ce['extension'] . " (Pass: " . $ce['password'] . ")\n";
                }
                $existingNotes = Capsule::table('tblhosting')->where('id', $params['serviceid'])->value('notes');
                Capsule::table('tblhosting')->where('id', $params['serviceid'])->update([
                    'notes' => trim($existingNotes . "\n\n" . $note)
                ]);
            }
            return 'success';
        }
        return $res['message'] ?? 'PBX termination soft-lock failed';
    } catch (\Exception $e) {
        return 'Exception: ' . $e->getMessage();
    }
}

/**
 * Admin Area Custom Buttons
 */
/**
 * Service Package Upgrade/Downgrade:
 * Adjusts extension count automatically on the assigned PBX server node.
 */
function whiteinfopbx_ChangePackage($params) {
    try {
        $extCount = 3;
        if (!empty($params['configoptions']['Extensions'])) {
            $extCount = intval($params['configoptions']['Extensions']);
        } elseif (!empty($params['configoptions']['ext_count'])) {
            $extCount = intval($params['configoptions']['ext_count']);
        } elseif (!empty($params['customfields']['Extension Count'])) {
            $extCount = intval($params['customfields']['Extension Count']);
        } elseif (!empty($params['configoption1'])) {
            $extCount = intval($params['configoption1']);
        }
        if ($extCount < 1) $extCount = 1;
        
        $res = whiteinfopbx_ApiCall($params, 'change_package', ['ext_count' => $extCount]);
        if (isset($res['status']) && $res['status'] === 'success') {
            if (!empty($res['created_extensions'])) {
                $note = "=== PACKAGE UPGRADE (" . date('Y-m-d H:i:s') . ") ===\n";
                $note .= "Total Extensions: " . $extCount . "\n";
                $note .= "Newly Added Extensions:\n";
                foreach ($res['created_extensions'] as $ce) {
                    $note .= "  • Ext " . $ce['extension'] . " (Pass: " . $ce['password'] . ")\n";
                }
                $existingNotes = Capsule::table('tblhosting')->where('id', $params['serviceid'])->value('notes');
                Capsule::table('tblhosting')->where('id', $params['serviceid'])->update([
                    'notes' => trim($existingNotes . "\n\n" . $note)
                ]);
            }
            return 'success';
        }
        return $res['message'] ?? 'Change package failed on PBX';
    } catch (\Exception $e) {
        return 'Exception: ' . $e->getMessage();
    }
}

function whiteinfopbx_AdminCustomButtonArray() {
    return [
        'Sync Status & Extensions' => 'SyncStatus',
    ];
}

function whiteinfopbx_SyncStatus($params) {
    $res = whiteinfopbx_ApiCall($params, 'status');
    if (isset($res['status']) && $res['status'] === 'success') {
        $serverHost = !empty($params['serverhostname']) ? $params['serverhostname'] : 'pbx1.whiteinfobd.com';
        return 'Node: ' . $serverHost . ' | Domain: ' . $res['domain'] . ' | Extensions: ' . $res['extension_count'] . ' | 30d Recordings: ' . ($res['recordings_count_30d'] ?? 0);
    }
    return $res['message'] ?? 'Failed to query PBX status';
}

/**
 * WHMCS Native Server Connection Test
 */
function whiteinfopbx_TestConnection($params) {
    $res = whiteinfopbx_ApiCall($params, 'ping');
    if (isset($res['status']) && $res['status'] === 'success') {
        return ['success' => true];
    }
    return ['error' => $res['message'] ?? 'PBX API connection test failed'];
}

/**
 * Client Area Dashboard (Multi-Server Dynamic)
 */
/**
 * WHMCS Native Service Single Sign-On (SSO)
 */
function whiteinfopbx_ServiceSingleSignOn($params) {
    try {
        $res = whiteinfopbx_ApiCall($params, 'sso');
        if (isset($res['status']) && $res['status'] === 'success' && !empty($res['sso_url'])) {
            return [
                'success' => true,
                'redirectTo' => $res['sso_url'],
            ];
        }
        return [
            'success' => false,
            'errorMsg' => $res['message'] ?? 'Failed to generate SSO token',
        ];
    } catch (\Exception $e) {
        return [
            'success' => false,
            'errorMsg' => $e->getMessage(),
        ];
    }
}

function whiteinfopbx_ClientArea($params) {
    $statusData = whiteinfopbx_ApiCall($params, 'status');
    $ssoData = whiteinfopbx_ApiCall($params, 'sso');
    $domain = !empty($statusData['domain']) ? $statusData['domain'] : $params['domain'];
    $ssoUrl = !empty($ssoData['sso_url']) ? $ssoData['sso_url'] : ("https://" . $domain . "/login.php");
    $isSuspended = ($params['status'] === 'Suspended');
    $username = htmlspecialchars($params['username'] ?? '');
    $password = htmlspecialchars($params['password'] ?? '');
    $extensions = !empty($statusData['extensions']) ? $statusData['extensions'] : [];
    $recCount = isset($statusData['recordings_count_30d']) ? intval($statusData['recordings_count_30d']) : 0;
    
    $serverHost = !empty($params['serverhostname']) ? $params['serverhostname'] : (!empty($params['serverip']) ? $params['serverip'] : 'pbx1.whiteinfobd.com');

    // Handle Extension Password Change Form Submission
    $extPassMsgHtml = '';
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['whiteinfopbx_custom_action']) && $_POST['whiteinfopbx_custom_action'] === 'change_extension_password') {
        $targetExt = trim($_POST['extension'] ?? '');
        $newPass = trim($_POST['new_password'] ?? '');
        if (empty($targetExt)) {
            $extPassMsgHtml = '<div style="background:#fef2f2;border:1px solid #f87171;color:#991b1b;padding:12px 16px;border-radius:8px;margin-bottom:18px;font-size:14px;"><i class="fa fa-times-circle"></i> Extension number is required.</div>';
        } else {
            $updateRes = whiteinfopbx_ApiCall($params, 'update_extension_password', [
                'extension' => $targetExt,
                'password' => $newPass
            ]);
            if (!empty($updateRes['status']) && $updateRes['status'] === 'success') {
                $effectiveNewPass = htmlspecialchars($updateRes['password'] ?? $newPass);
                $extPassMsgHtml = '<div style="background:#f0fdf4;border:1px solid #4ade80;color:#166534;padding:12px 16px;border-radius:8px;margin-bottom:18px;font-size:14px;"><i class="fa fa-check-circle" style="color:#16a34a;"></i> Password for Extension <strong>' . htmlspecialchars($targetExt) . '</strong> has been successfully updated to: <code style="font-family:monospace;font-weight:700;background:#dcfce7;padding:3px 8px;border-radius:4px;color:#166534;">' . $effectiveNewPass . '</code>! Please update your softphone (MicroSIP / Zoiper) with this new password.</div>';
                // Reload status data so updated extension password is shown in the table
                $statusData = whiteinfopbx_ApiCall($params, 'status');
                $extensions = !empty($statusData['extensions']) ? $statusData['extensions'] : $extensions;
            } else {
                $errMsg = htmlspecialchars($updateRes['message'] ?? 'Failed to communicate with PBX server');
                $extPassMsgHtml = '<div style="background:#fef2f2;border:1px solid #f87171;color:#991b1b;padding:12px 16px;border-radius:8px;margin-bottom:18px;font-size:14px;"><i class="fa fa-exclamation-triangle"></i> Password update failed: ' . $errMsg . '</div>';
            }
        }
    }

    // Detect visitor IP for self-service unblock
    $clientIp = '';
    if (!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) {
        $clientIp = $_SERVER['HTTP_CF_CONNECTING_IP'];
    } elseif (!empty($_SERVER['HTTP_X_REAL_IP'])) {
        $clientIp = $_SERVER['HTTP_X_REAL_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $fwd = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        $clientIp = trim($fwd[0]);
    } elseif (!empty($_SERVER['REMOTE_ADDR'])) {
        $clientIp = $_SERVER['REMOTE_ADDR'];
    }
    $clientIp = trim($clientIp);

    // Handle Unblock Form Submission
    $unblockMsgHtml = '';
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['whiteinfopbx_custom_action']) && $_POST['whiteinfopbx_custom_action'] === 'unblock_ip') {
        $targetIp = trim($_POST['ip_address'] ?? '');
        if (empty($targetIp) || !filter_var($targetIp, FILTER_VALIDATE_IP)) {
            $unblockMsgHtml = '<div style="background:#fef2f2;border:1px solid #f87171;color:#991b1b;padding:12px 16px;border-radius:8px;margin-bottom:18px;font-size:14px;"><i class="fa fa-times-circle"></i> Please enter a valid IPv4 or IPv6 address.</div>';
        } else {
            $unblockRes = whiteinfopbx_ApiCall($params, 'unblock_ip', ['ip' => $targetIp]);
            if (!empty($unblockRes['status']) && $unblockRes['status'] === 'success') {
                $unblockMsgHtml = '<div style="background:#f0fdf4;border:1px solid #4ade80;color:#166534;padding:12px 16px;border-radius:8px;margin-bottom:18px;font-size:14px;"><i class="fa fa-check-circle" style="color:#16a34a;"></i> IP <strong>' . htmlspecialchars($targetIp) . '</strong> has been successfully unblocked from FreeSWITCH Event Guard and Server Firewall! You can now register extensions and connect.</div>';
            } else {
                $errMsg = htmlspecialchars($unblockRes['message'] ?? 'Failed to communicate with PBX server');
                $unblockMsgHtml = '<div style="background:#fef2f2;border:1px solid #f87171;color:#991b1b;padding:12px 16px;border-radius:8px;margin-bottom:18px;font-size:14px;"><i class="fa fa-exclamation-triangle"></i> Unblock failed: ' . $errMsg . '</div>';
            }
        }
    }

    // Check if detected IP is currently blocked
    $isClientBlocked = false;
    if (!empty($clientIp) && filter_var($clientIp, FILTER_VALIDATE_IP)) {
        $checkRes = whiteinfopbx_ApiCall($params, 'check_ip', ['ip' => $clientIp]);
        $isClientBlocked = !empty($checkRes['is_blocked']);
    }

    $blockedAlertBanner = '';
    if ($isClientBlocked) {
        $blockedAlertBanner = '<div style="background:#fef2f2;border:2px solid #ef4444;border-radius:8px;padding:14px 18px;margin-bottom:20px;color:#991b1b;font-size:14px;">
            <div style="display:flex;align-items:center;gap:10px;">
                <i class="fa fa-ban" style="font-size:24px;color:#dc2626;"></i>
                <div>
                    <h5 style="margin:0 0 4px 0;font-weight:700;color:#b91c1c;">IP Block Detected!</h5>
                    Your current IP (<strong>' . htmlspecialchars($clientIp) . '</strong>) is currently <strong>BLOCKED</strong> by PBX Event Guard / Firewall due to failed password attempts. Click the unblock button below to restore access immediately.
                </div>
            </div>
        </div>';
    }
    
    // Build extensions table rows
    $extRows = '';
    foreach ($extensions as $ext) {
        $extNum = htmlspecialchars($ext['extension']);
        $extName = htmlspecialchars($ext['effective_caller_id_name']);
        $extPass = htmlspecialchars($ext['password'] ?? '');
        $enabled = !empty($ext['enabled']);
        
        $is999 = ($extNum === '999');
        $rowBadge = '';
        if ($is999) {
            $rowBadge = '<span class="label label-primary" style="background:#0284c7;color:#fff;padding:3px 8px;border-radius:4px;font-size:11px;">FREE / SUPPORT (ALWAYS ACTIVE)</span>';
        } elseif ($enabled) {
            $rowBadge = '<span class="label label-success" style="background:#16a34a;color:#fff;padding:3px 8px;border-radius:4px;font-size:11px;">ACTIVE</span>';
        } else {
            $rowBadge = '<span class="label label-danger" style="background:#dc2626;color:#fff;padding:3px 8px;border-radius:4px;font-size:11px;">OFF (OVERDUE)</span>';
        }
        
        $extRows .= "<tr>
            <td><strong style='font-size:15px;color:#1e293b;'>{$extNum}</strong></td>
            <td>{$extName}</td>
            <td>
                <div style='display:inline-flex;align-items:center;gap:6px;'>
                    <code id='pass_val_{$extNum}' style='font-family:monospace;font-size:13px;background:#f1f5f9;padding:3px 8px;border-radius:4px;color:#0f172a;border:1px solid #e2e8f0;'>{$extPass}</code>
                    <button type='button' onclick='navigator.clipboard.writeText(\"{$extPass}\");alert(\"Password copied to clipboard: {$extPass}\");' title='Copy Password' class='btn btn-xs btn-default' style='background:#fff;border:1px solid #cbd5e1;padding:2px 6px;border-radius:4px;cursor:pointer;'><i class='fa fa-copy'></i></button>
                </div>
            </td>
            <td>{$domain}</td>
            <td>{$rowBadge}</td>
            <td style='text-align:right;'>
                <button type='button' onclick='openExtPassModal(\"{$extNum}\", \"{$extPass}\")' class='btn btn-xs btn-primary' style='background:#2563eb;color:#fff;border:none;padding:5px 10px;border-radius:5px;font-size:12px;font-weight:600;display:inline-flex;align-items:center;gap:5px;cursor:pointer;'>
                    <i class='fa fa-key'></i> Change Password
                </button>
            </td>
        </tr>";
    }
    
    $bannerHtml = '';
    if ($isSuspended) {
        $bannerHtml = '<div style="background:#fee2e2;border:1px solid #ef4444;border-radius:8px;padding:15px;margin-bottom:20px;color:#991b1b;">
            <h4 style="margin:0 0 8px 0;font-weight:700;"><i class="fa fa-exclamation-triangle"></i> Service Suspended (Invoice Overdue)</h4>
            <p style="margin:0 0 5px 0;">All customer extensions have been turned off due to non-payment. Please pay your invoice to instantly restore your package extensions.</p>
            <p style="margin:0;font-weight:600;"><i class="fa fa-check-circle" style="color:#16a34a;"></i> <strong>Extension 999</strong> remains ACTIVE and fully available for free emergency and support calling!</p>
        </div>';
    }
    
    $html = <<<HTML
<div style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;">
    {$bannerHtml}
    
    <!-- PBX Tenant Overview -->
    <div style="display:flex;justify-content:space-between;align-items:center;background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:18px 24px;margin-bottom:24px;flex-wrap:wrap;gap:15px;">
        <div>
            <div style="font-size:12px;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:0.5px;">PBX Tenant Subdomain</div>
            <div style="font-size:22px;font-weight:800;color:#0f172a;margin-top:2px;">
                <a href="https://{$domain}" target="_blank" style="color:#2563eb;text-decoration:none;">{$domain}</a>
            </div>
            <div style="font-size:13px;color:#64748b;margin-top:4px;">
                <i class="fa fa-server"></i> PBX Node: <strong>{$serverHost}</strong> | SIP Server: <strong>{$domain}:5060</strong>
            </div>
        </div>
        <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;">
            <a href="{$ssoUrl}" target="_blank" class="btn btn-primary" style="background:#16a34a;color:#fff;border-radius:6px;padding:10px 18px;font-weight:600;text-decoration:none;display:inline-flex;align-items:center;gap:6px;">
                <i class="fa fa-sign-in"></i> One-Click PBX Login
            </a>
            <a href="https://{$domain}" target="_blank" class="btn btn-default" style="background:#f1f5f9;color:#334155;border:1px solid #cbd5e1;border-radius:6px;padding:9px 16px;font-weight:600;text-decoration:none;display:inline-flex;align-items:center;gap:6px;">
                <i class="fa fa-external-link"></i> Open URL
            </a>
        </div>
    </div>

    <!-- Web Portal Admin Credentials -->
    <div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:10px;padding:18px 20px;margin-bottom:24px;color:#166534;">
        <h4 style="margin:0 0 10px 0;font-weight:700;color:#166534;"><i class="fa fa-lock"></i> PBX Web Portal Login Credentials (*.whiteinfobd.com)</h4>
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px;font-size:14px;">
            <div style="background:#fff;padding:12px 16px;border-radius:6px;border:1px solid #dcfce7;">
                <div style="font-size:12px;color:#64748b;font-weight:600;">Web Portal URL</div>
                <div style="margin-top:4px;"><a href="https://{$domain}" target="_blank" style="color:#2563eb;font-weight:700;">https://{$domain}</a></div>
            </div>
            <div style="background:#fff;padding:12px 16px;border-radius:6px;border:1px solid #dcfce7;">
                <div style="font-size:12px;color:#64748b;font-weight:600;">Login Username</div>
                <div style="margin-top:4px;font-family:monospace;font-size:15px;font-weight:700;color:#0f172a;">{$username}</div>
            </div>
            <div style="background:#fff;padding:12px 16px;border-radius:6px;border:1px solid #dcfce7;">
                <div style="font-size:12px;color:#64748b;font-weight:600;">Login Password</div>
                <div style="margin-top:4px;font-family:monospace;font-size:15px;font-weight:700;color:#0f172a;">{$password}</div>
            </div>
            <div style="background:#fff;padding:12px 16px;border-radius:6px;border:1px solid #dcfce7;">
                <div style="font-size:12px;color:#64748b;font-weight:600;">User Role & Permission</div>
                <div style="margin-top:4px;font-weight:700;color:#16a34a;"><i class="fa fa-building"></i> Company Role (Company Admin)</div>
            </div>
        </div>
    </div>

    {$extPassMsgHtml}

    <!-- Provisioned Extensions Table -->
    <div style="background:#fff;border:1px solid #e2e8f0;border-radius:10px;overflow:hidden;margin-bottom:24px;box-shadow:0 1px 3px rgba(0,0,0,0.05);">
        <div style="background:#f1f5f9;padding:14px 20px;font-weight:700;font-size:15px;color:#1e293b;border-bottom:1px solid #e2e8f0;display:flex;justify-content:space-between;align-items:center;">
            <span><i class="fa fa-phone"></i> Provisioned Extensions</span>
            <span style="font-size:12px;font-weight:600;color:#64748b;">30-Day Call Recordings: <strong>{$recCount} calls stored</strong></span>
        </div>
        <div class="table-responsive" style="margin:0;">
            <table class="table" style="margin-bottom:0;width:100%;">
                <thead>
                    <tr style="background:#f8fafc;font-size:12px;text-transform:uppercase;color:#64748b;">
                        <th>Extension</th>
                        <th>Caller ID / Name</th>
                        <th>SIP Password</th>
                        <th>SIP Domain Context</th>
                        <th>Status</th>
                        <th style="text-align:right;">Action</th>
                    </tr>
                </thead>
                <tbody>
                    {$extRows}
                </tbody>
            </table>
        </div>
    </div>

    <!-- Self-Service Firewall & IP Unblock Tool -->
    <div style="background:#f8fafc;border:1px solid #cbd5e1;border-radius:10px;padding:20px;margin-bottom:24px;box-shadow:0 1px 3px rgba(0,0,0,0.04);">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px;flex-wrap:wrap;gap:10px;">
            <h4 style="margin:0;font-weight:700;color:#0f172a;display:flex;align-items:center;gap:8px;">
                <i class="fa fa-shield" style="color:#2563eb;"></i> Firewall & Event Guard IP Unblock Tool
            </h4>
            <div style="font-size:13px;color:#64748b;">
                Your Detected IP: <code style="font-family:monospace;font-weight:700;background:#e2e8f0;padding:2px 8px;border-radius:4px;color:#0f172a;">{$clientIp}</code>
            </div>
        </div>

        <p style="margin:0 0 16px 0;font-size:13px;color:#475569;">
            If softphones (MicroSIP, Zoiper, IP Phone) or web logins fail multiple times with wrong credentials, PBX Event Guard automatically blocks the IP to prevent brute-force attacks. You can unblock your current office IP or any branch IP anytime below.
        </p>

        {$unblockMsgHtml}
        {$blockedAlertBanner}

        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:16px;">
            <!-- Option 1: 1-Click Current IP Unblock -->
            <div style="background:#ffffff;border:1px solid #e2e8f0;border-radius:8px;padding:16px;">
                <div style="font-size:14px;font-weight:700;color:#1e293b;margin-bottom:6px;">
                    <i class="fa fa-bolt" style="color:#16a34a;"></i> 1-Click Current IP Unblock
                </div>
                <div style="font-size:12px;color:#64748b;margin-bottom:12px;">
                    Instantly unblock your current internet IP: <strong>{$clientIp}</strong>
                </div>
                <form method="post" action="" style="margin:0;">
                    <input type="hidden" name="whiteinfopbx_custom_action" value="unblock_ip">
                    <input type="hidden" name="ip_address" value="{$clientIp}">
                    <button type="submit" class="btn btn-success" style="width:100%;background:#16a34a;border:none;padding:10px 14px;font-weight:600;border-radius:6px;display:flex;align-items:center;justify-content:center;gap:8px;color:#fff;">
                        <i class="fa fa-unlock"></i> Unblock My IP ({$clientIp})
                    </button>
                </form>
            </div>

            <!-- Option 2: Custom IP Unblock -->
            <div style="background:#ffffff;border:1px solid #e2e8f0;border-radius:8px;padding:16px;">
                <div style="font-size:14px;font-weight:700;color:#1e293b;margin-bottom:6px;">
                    <i class="fa fa-laptop" style="color:#2563eb;"></i> Unblock Custom / Branch IP
                </div>
                <div style="font-size:12px;color:#64748b;margin-bottom:12px;">
                    Enter any branch office or remote worker IP address to unblock:
                </div>
                <form method="post" action="" style="margin:0;display:flex;gap:8px;flex-wrap:wrap;">
                    <input type="hidden" name="whiteinfopbx_custom_action" value="unblock_ip">
                    <input type="text" name="ip_address" placeholder="e.g. 103.15.140.151" class="form-control" style="flex:1;min-width:160px;font-family:monospace;padding:8px 12px;border:1px solid #cbd5e1;border-radius:6px;" required>
                    <button type="submit" class="btn btn-primary" style="background:#2563eb;border:none;padding:10px 16px;font-weight:600;border-radius:6px;display:inline-flex;align-items:center;gap:6px;color:#fff;">
                        <i class="fa fa-unlock"></i> Unblock
                    </button>
                </form>
            </div>
        </div>
    </div>

    <!-- MicroSIP Setup Guide -->
    <div style="background:#eff6ff;border:1px solid #bfdbfe;border-radius:10px;padding:20px;margin-bottom:24px;">
        <h4 style="margin:0 0 12px 0;font-weight:700;color:#1e40af;"><i class="fa fa-laptop"></i> MicroSIP / Softphone Quick Setup Guide</h4>
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px;font-size:13px;color:#1e3a8a;">
            <div><strong>SIP Server / Proxy:</strong><br><span style="font-family:monospace;font-size:14px;background:#fff;padding:2px 6px;border-radius:4px;border:1px solid #dbeafe;">{$domain}</span></div>
            <div><strong>SIP Port:</strong><br><span style="font-family:monospace;font-size:14px;background:#fff;padding:2px 6px;border-radius:4px;border:1px solid #dbeafe;">5060 (UDP)</span></div>
            <div><strong>Username:</strong><br><span style="font-family:monospace;font-size:14px;background:#fff;padding:2px 6px;border-radius:4px;border:1px solid #dbeafe;">[Extension Number]</span></div>
            <div><strong>Domain / Realm:</strong><br><span style="font-family:monospace;font-size:14px;background:#fff;padding:2px 6px;border-radius:4px;border:1px solid #dbeafe;">{$domain}</span></div>
        </div>
        <p style="margin:12px 0 0 0;font-size:12px;color:#3b82f6;">
            <i class="fa fa-info-circle"></i> Password for each extension is shown in your service activation email or can be viewed in your PBX Web Portal under <strong>Accounts &gt; Extensions</strong>.
        </p>
    </div>

    <!-- 30-Day Recording Policy -->
    <div style="background:#fffbeb;border:1px solid #fde68a;border-radius:8px;padding:12px 16px;color:#92400e;font-size:13px;margin-bottom:20px;">
        <i class="fa fa-clock-o" style="font-weight:700;"></i> <strong>Call Recordings Retention Policy:</strong> All call recordings are securely stored for <strong>30 days</strong> and automatically cleaned up thereafter. You can download important recordings anytime from your PBX portal.
    </div>

    <!-- Extension Password Change Modal -->
    <div id="extPassModal" style="display:none;position:fixed;z-index:99999;left:0;top:0;width:100%;height:100%;overflow:auto;background-color:rgba(15,23,42,0.6);backdrop-filter:blur(2px);">
        <div style="background-color:#ffffff;margin:10% auto;padding:24px 28px;border:1px solid #cbd5e1;border-radius:12px;width:90%;max-width:480px;box-shadow:0 20px 25px -5px rgba(0,0,0,0.1),0 10px 10px -5px rgba(0,0,0,0.04);">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;">
                <h4 style="margin:0;font-weight:700;color:#0f172a;display:flex;align-items:center;gap:8px;">
                    <i class="fa fa-key" style="color:#2563eb;"></i> Change Extension Password
                </h4>
                <button type="button" onclick="closeExtPassModal()" style="background:none;border:none;font-size:24px;cursor:pointer;color:#64748b;line-height:1;">&times;</button>
            </div>
            
            <form method="post" action="" style="margin:0;">
                <input type="hidden" name="whiteinfopbx_custom_action" value="change_extension_password">
                <input type="hidden" id="modalExtInput" name="extension" value="">
                
                <div style="margin-bottom:14px;">
                    <label style="font-size:13px;font-weight:600;color:#334155;margin-bottom:4px;display:block;">Extension Number</label>
                    <div id="modalExtDisplay" style="font-size:16px;font-weight:700;color:#1e293b;background:#f8fafc;padding:8px 12px;border-radius:6px;border:1px solid #e2e8f0;"></div>
                </div>

                <div style="margin-bottom:18px;">
                    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px;">
                        <label style="font-size:13px;font-weight:600;color:#334155;margin:0;">New SIP Password</label>
                        <button type="button" onclick="generateRandomPass()" style="background:none;border:none;color:#2563eb;font-size:12px;font-weight:600;cursor:pointer;padding:0;">
                            <i class="fa fa-random"></i> Generate Strong Password
                        </button>
                    </div>
                    <input type="text" id="modalNewPassInput" name="new_password" class="form-control" style="font-family:monospace;font-size:14px;padding:8px 12px;border:1px solid #cbd5e1;border-radius:6px;width:100%;box-sizing:border-box;" required minlength="6" maxlength="64">
                    <small style="color:#64748b;font-size:12px;margin-top:6px;display:block;">Minimum 6 characters. Click "Generate" to create a secure 16-character password.</small>
                </div>

                <div style="display:flex;justify-content:flex-end;gap:10px;">
                    <button type="button" onclick="closeExtPassModal()" class="btn btn-default" style="padding:8px 16px;border-radius:6px;font-weight:600;">Cancel</button>
                    <button type="submit" class="btn btn-primary" style="background:#2563eb;border:none;padding:8px 18px;border-radius:6px;font-weight:600;color:#fff;">
                        <i class="fa fa-save"></i> Save New Password
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>
    function openExtPassModal(ext, currentPass) {
        document.getElementById('modalExtInput').value = ext;
        document.getElementById('modalExtDisplay').textContent = 'Extension ' + ext;
        document.getElementById('modalNewPassInput').value = currentPass || '';
        document.getElementById('extPassModal').style.display = 'block';
    }
    function closeExtPassModal() {
        document.getElementById('extPassModal').style.display = 'none';
    }
    function generateRandomPass() {
        const chars = 'abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789!@#$%&*';
        let pass = '';
        for (let i = 0; i < 16; i++) {
            pass += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        document.getElementById('modalNewPassInput').value = pass;
    }
    window.onclick = function(event) {
        const modal = document.getElementById('extPassModal');
        if (event.target == modal) {
            closeExtPassModal();
        }
    }
    </script>
</div>
HTML;

    return $html;
}

/**
 * Admin Area Service Management Fields (View extensions & change passwords from admin)
 */
function whiteinfopbx_AdminServicesTabFields($params) {
    $statusData = whiteinfopbx_ApiCall($params, 'status');
    $extensions = !empty($statusData['extensions']) ? $statusData['extensions'] : [];
    
    $rows = '';
    foreach ($extensions as $ext) {
        $extNum = htmlspecialchars($ext['extension']);
        $extPass = htmlspecialchars($ext['password'] ?? '');
        $extName = htmlspecialchars($ext['effective_caller_id_name'] ?? '');
        $enabled = !empty($ext['enabled']) ? '<span class="label label-success">Active</span>' : '<span class="label label-danger">Disabled</span>';
        
        $rows .= "<tr>
            <td><strong>{$extNum}</strong></td>
            <td>{$extName}</td>
            <td><code>{$extPass}</code></td>
            <td>{$enabled}</td>
            <td>
                <input type='text' name='whiteinfopbx_new_pass_{$extNum}' placeholder='New password or leave blank' class='form-control input-sm' style='width:180px;display:inline-block;'>
            </td>
        </tr>";
    }
    
    $html = "<table class='table table-condensed table-striped' style='margin:0;'>
        <thead>
            <tr>
                <th>Extension</th>
                <th>Caller ID Name</th>
                <th>Current SIP Password</th>
                <th>Status</th>
                <th>Set New Password</th>
            </tr>
        </thead>
        <tbody>
            {$rows}
        </tbody>
    </table>
    <small class='text-muted' style='margin-top:5px;display:block;'>Enter a new password in the field above and click \x27Save Changes\x27 to update the SIP extension password on the PBX server.</small>";
    
    return [
        'PBX Extensions & Passwords' => $html,
    ];
}

/**
 * Save Admin Area Service Management Fields
 */
function whiteinfopbx_AdminServicesTabFieldsSave($params) {
    foreach ($_POST as $key => $val) {
        if (strpos($key, 'whiteinfopbx_new_pass_') === 0 && !empty($val)) {
            $extNum = substr($key, strlen('whiteinfopbx_new_pass_'));
            $newPass = trim($val);
            if (!empty($extNum) && !empty($newPass)) {
                whiteinfopbx_ApiCall($params, 'update_extension_password', [
                    'extension' => $extNum,
                    'password' => $newPass
                ]);
            }
        }
    }
}
